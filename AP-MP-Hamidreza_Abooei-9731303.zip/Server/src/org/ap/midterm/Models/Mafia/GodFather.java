package org.ap.midterm.Models.Mafia;

/**
 * @author Hamidreza Abooei
 */
public class GodFather extends Mafia {
    /**
     * constructor
     */
    public GodFather(){
        super();
        super.setName("GodFather");
        super.killer = true;
    }
}
