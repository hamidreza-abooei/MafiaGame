package org.ap.midterm.Models.Citizen;
/**
 * @author Hamidreza Abooei
 */
public class Detective extends Citizen{
    /**
     * constructor
     */
    public Detective(){
        super();
        super.setName("Detective");
    }
}
