package org.ap.midterm.Models.Citizen;
/**
 * @author Hamidreza Abooei
 */
public class Hunter extends Citizen{
    /**
     * constructor
     */
    public Hunter(){
        super();
        super.setName("Hunter");
    }
}
