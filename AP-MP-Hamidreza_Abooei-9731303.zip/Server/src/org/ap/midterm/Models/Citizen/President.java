package org.ap.midterm.Models.Citizen;
/**
 * @author Hamidreza Abooei
 */
public class President extends Citizen{
    /**
     * constructor
     */
    public President(){
        super();
        super.setName("President");
    }
}
