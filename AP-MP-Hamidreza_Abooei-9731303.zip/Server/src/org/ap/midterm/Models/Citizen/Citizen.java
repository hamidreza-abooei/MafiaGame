package org.ap.midterm.Models.Citizen;

import org.ap.midterm.Models.Player;
/**
 * @author Hamidreza Abooei
 */
public class Citizen extends Player {
    /**
     * constructor
     */
    public Citizen (){
        super();
        super.setName("Citizen");
    }
}
