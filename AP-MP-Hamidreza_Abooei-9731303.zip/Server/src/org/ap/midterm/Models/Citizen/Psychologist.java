package org.ap.midterm.Models.Citizen;
/**
 * @author Hamidreza Abooei
 */
public class Psychologist extends Citizen{
    /**
     * constructor
     */
    public Psychologist(){
        super();
        super.setName("Psychologist");
    }
}
