package org.ap.midterm.Models;
/**
 * Determine the Game Mode
 * @author Hamidreza Abooei
 */

public enum GameMode {
    DAY,NIGHT,ELECTION
}
